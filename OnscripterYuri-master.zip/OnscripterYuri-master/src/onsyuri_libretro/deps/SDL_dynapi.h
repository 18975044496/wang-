#ifndef SDL_dynapi_h_
#define SDL_dynapi_h_

#define SDL_DYNAMIC_API 0

#endif
